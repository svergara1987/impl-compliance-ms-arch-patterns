package uy.edu.fing.svergara.circuitbreakerhystrix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircuitBreakerHystrixApplication {

	public static void main(String[] args) {
		SpringApplication.run(CircuitBreakerHystrixApplication.class, args);
	}

}
