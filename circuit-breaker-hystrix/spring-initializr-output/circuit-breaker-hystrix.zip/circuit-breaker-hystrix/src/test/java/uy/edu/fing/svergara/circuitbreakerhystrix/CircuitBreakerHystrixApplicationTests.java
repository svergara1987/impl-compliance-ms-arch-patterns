package uy.edu.fing.svergara.circuitbreakerhystrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitBreakerHystrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
